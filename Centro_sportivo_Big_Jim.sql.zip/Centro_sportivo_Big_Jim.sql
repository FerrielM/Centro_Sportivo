-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: Centro_Sportivo_Big_Jim
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anagrafica`
--

DROP TABLE IF EXISTS `anagrafica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anagrafica` (
  `id_anagrafica` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `cognome` varchar(255) DEFAULT NULL,
  `indirizzo` varchar(255) DEFAULT NULL,
  `cap` varchar(5) DEFAULT NULL,
  `localita` varchar(255) DEFAULT NULL,
  `provincia` varchar(2) DEFAULT NULL,
  `codice_fiscale` varchar(16) DEFAULT NULL,
  `partita_iva` varchar(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `telefono_cellulare` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_anagrafica`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anagrafica`
--

LOCK TABLES `anagrafica` WRITE;
/*!40000 ALTER TABLE `anagrafica` DISABLE KEYS */;
INSERT INTO `anagrafica` VALUES (1,'Marco ','Masiello','Via A Tenna Stinnicchiata, 8 ','80100','Napoli','NA','ZWFCLF46C52G833E','15985985','masiello@esempio.com','3335859689'),(2,'Ferriel','Merouane','Via Esotica, 33','12100','Cuneo','CN','KCVBPM78B16H269G','45458798','merouane@esempio.com','3274848459'),(3,'Stefania','Palatucci','Via Delle Grafiche,128','83100','Avellino','AV','WOAQKL49C02C186P','35789547','palatucci@esempio.com','34856598658'),(4,'Alessandro','Lanaro','Via Gin Fizz, 22','10135','Torino','TO','MPWBSP94D50A187Q','654987589','lanaro@esempio.com','3332525689'),(5,'Lorenzo','Petraroli','via dei Lorenzi, 44','73048','Lecce','LE','MNPZSC35L63D921Y','3578548','lorenz@esmpio.com','3485654879'),(6,'Primo','Cliente','Via dei pazzoni','80100','Napoli','NA','idugqdidif23','15985478','clientone@esempio.com','33333333333');
/*!40000 ALTER TABLE `anagrafica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `id_area` int(11) NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(255) DEFAULT NULL,
  `posti_disponibili` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_area`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (2,'Piscina',NULL),(3,'Sala Climbing',NULL),(4,'Studio Medico',NULL),(5,'Sala A',NULL),(6,'Sala B',NULL),(10,'Area Pesi',NULL),(11,'Sala Wellness',NULL);
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corsi`
--

DROP TABLE IF EXISTS `corsi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corsi` (
  `id_corso` int(11) NOT NULL AUTO_INCREMENT,
  `id_area` int(11) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `descrizione` text DEFAULT NULL,
  `prezzo` double DEFAULT NULL,
  PRIMARY KEY (`id_corso`),
  KEY `id_area` (`id_area`),
  CONSTRAINT `corsi_ibfk_1` FOREIGN KEY (`id_area`) REFERENCES `area` (`id_area`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corsi`
--

LOCK TABLES `corsi` WRITE;
/*!40000 ALTER TABLE `corsi` DISABLE KEYS */;
INSERT INTO `corsi` VALUES (1,10,'Calisthenics','Il calisthenics è l\'arte di usare il proprio peso corporeo come resistenza per allenarsi e sviluppare il fisico tramite un istema di allenamento basato sulla ginnastica a corpo libero.',NULL),(2,5,'Musical Fitness','fitness musicale di gruppo',NULL),(3,10,'Crosstraining','Il Cross Training, o allenamento incrociato, è una modalità di allenamento che permette di praticare più discipline sportive, variando ogni giorno le catene muscolari utilizzate e allenando costantemente il sistema cardio-respiratorio e la risposta ormonale all’esercizio fisico.',NULL),(4,6,'Fit Box','Fit boxe è un metodo di allenamento fitness – concepito per ottimizzare lo stato di forma fisica generale – sviluppato in stile kickboxing.',NULL),(5,6,'Aerobica e Step Coreografico','La ginnastica aerobica è una sessione di workout in cui si susseguono vari esercizi eseguiti a corpo libero o con attrezzi come lo step, tutto nell’arco temporale di un’ora circa.',NULL),(6,11,'Riequilibrio Posturale','La Rieducazione Posturale, meglio nota come Ginnastica Posturale, è una metodica specifica che consta di una serie di esercizi atti a riequilibrare le tensioni muscolo-legamentose del corpo.',NULL),(7,5,'Ginnastica Kids','L’esercizio fisico ha un ruolo prioritario per la salute durante lo sviluppo dei bambini. Oltre ad essere divertente, l’attività motoria nei più piccoli contribuisce a migliorare le condizioni di salute fisica e a promuovere il benessere psicologico, indispensabili per una crescita sana.',NULL),(8,11,'Dinamic Yoga','Ciò che viene chiamato Yoga dinamico si distingue da quello tradizionale poiché propone lo svolgimento di una concatenazione fluida di posture ad un ritmo rapido e sportivo, mantenendo una respirazione lenta e profonda.',NULL),(9,5,'Group Sparring','Un allenamento “one to one” a coppie che prende spunto dalla pre-pugilistica e dalle attività di sparring delle arti marziali, ma ricodificate in chiave fitness musicale',NULL),(10,6,'Pilates and Stretch','l corso di Stretch Pilates si propone di aiutare gli allievi a conoscere il proprio corpo al meglio, a tonificarlo, a decontrarlo e a migliorarlo.\r\nStretch Pilates è tonificazione muscolare applicata ad una respirazione ben precisa, alternata al dovuto stretching di rilassamento.',NULL),(11,10,'Total Body Workout','l total body workout da praticare sia a casa che in palestra, si compone di una varietà di esercizi e tecniche di allenamento differenti che contribuiscono a bruciare calorie, aumentare il tono muscolare, forza e resistenza',NULL),(12,10,'Functional Training','Grazie alle diverse modalità di esecuzione e alle diverse velocità di contrazione muscolare, migliora la coordinazione tra i vari gruppi muscolari, sviluppa l\'agilità, aumenta l\'elasticità nelle articolazioni e il tono e la potenza muscolare.',NULL),(13,2,'Water Hydrobike','L\'hydrobike assicura benefici anche a livello cardiovascolare in quanto migliora la resistenza caridiocircolatoria. Infatti, il massaggio idrico continuo stimola la circolazione, oltre che tonificare, grazie alla resistenza creata con l\'acqua senza peraltro aumentare eccessivamente la massa muscolare.',NULL),(14,2,'Water Tone','È un\'attività di media intensità, mirata a sviluppare la tonificazione di tutti i distretti muscolari attraverso esercizi di coordinazione a difficoltà crescente.',NULL),(15,2,'Water Endurance','Un mix di diverse discipline per migliorare la tua capacità aerobica in un total body workout intenso e a ritmo di musica.',NULL);
/*!40000 ALTER TABLE `corsi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordini`
--

DROP TABLE IF EXISTS `ordini`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordini` (
  `id_ordine` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `data_ordine` datetime DEFAULT NULL,
  `modalita_di_pagamento` varchar(50) DEFAULT NULL,
  `prezzo` double DEFAULT NULL,
  PRIMARY KEY (`id_ordine`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `ordini_ibfk_5` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordini`
--

LOCK TABLES `ordini` WRITE;
/*!40000 ALTER TABLE `ordini` DISABLE KEYS */;
INSERT INTO `ordini` VALUES (2,NULL,'2022-05-19 16:11:06','Carta di credito',NULL),(3,NULL,'2022-05-22 09:14:24','Carta di credito',20);
/*!40000 ALTER TABLE `ordini` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prodotti_in_ordine`
--

DROP TABLE IF EXISTS `prodotti_in_ordine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prodotti_in_ordine` (
  `id_prodotti_in_ordine` int(11) NOT NULL AUTO_INCREMENT,
  `id_ordine` int(11) DEFAULT NULL,
  `id_corso` int(11) DEFAULT NULL,
  `id_tipologia_abbonamento` int(11) DEFAULT NULL,
  `totale_ordine` double DEFAULT NULL,
  PRIMARY KEY (`id_prodotti_in_ordine`),
  KEY `id_ordine` (`id_ordine`),
  KEY `id_corso` (`id_corso`),
  KEY `id_tipologia_abbonamento` (`id_tipologia_abbonamento`),
  CONSTRAINT `prodotti_in_ordine_ibfk_1` FOREIGN KEY (`id_tipologia_abbonamento`) REFERENCES `tipologie_abbonamento` (`id_tipologia_abbonamento`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `prodotti_in_ordine_ibfk_2` FOREIGN KEY (`id_corso`) REFERENCES `corsi` (`id_corso`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `prodotti_in_ordine_ibfk_3` FOREIGN KEY (`id_ordine`) REFERENCES `ordini` (`id_ordine`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prodotti_in_ordine`
--

LOCK TABLES `prodotti_in_ordine` WRITE;
/*!40000 ALTER TABLE `prodotti_in_ordine` DISABLE KEYS */;
/*!40000 ALTER TABLE `prodotti_in_ordine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ruoli`
--

DROP TABLE IF EXISTS `ruoli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ruoli` (
  `id_ruolo` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `descrizione` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_ruolo`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `ruoli_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ruoli`
--

LOCK TABLES `ruoli` WRITE;
/*!40000 ALTER TABLE `ruoli` DISABLE KEYS */;
INSERT INTO `ruoli` VALUES (1,1,'Personal Trainer'),(2,3,'Medico'),(3,2,'Insegnate Nuoto'),(4,4,'Personal Trainer'),(5,5,'Personal Trainer Yoga');
/*!40000 ALTER TABLE `ruoli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipologia_attivita`
--

DROP TABLE IF EXISTS `tipologia_attivita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipologia_attivita` (
  `id_tipologia_attivita` int(11) NOT NULL AUTO_INCREMENT,
  `descrizione` text DEFAULT NULL,
  `prezzo` double DEFAULT NULL,
  PRIMARY KEY (`id_tipologia_attivita`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipologia_attivita`
--

LOCK TABLES `tipologia_attivita` WRITE;
/*!40000 ALTER TABLE `tipologia_attivita` DISABLE KEYS */;
INSERT INTO `tipologia_attivita` VALUES (1,'prenotazione campo calcetto, 60\'.',16),(2,'prenotazione campo tennis 60\'.',19),(3,'prenotazione campo basket, 60\'.',12);
/*!40000 ALTER TABLE `tipologia_attivita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipologie_abbonamento`
--

DROP TABLE IF EXISTS `tipologie_abbonamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipologie_abbonamento` (
  `id_tipologia_abbonamento` int(11) NOT NULL AUTO_INCREMENT,
  `tipologia` varchar(255) DEFAULT NULL,
  `decrizione` text DEFAULT NULL,
  `prezzo` double DEFAULT NULL,
  PRIMARY KEY (`id_tipologia_abbonamento`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipologie_abbonamento`
--

LOCK TABLES `tipologie_abbonamento` WRITE;
/*!40000 ALTER TABLE `tipologie_abbonamento` DISABLE KEYS */;
INSERT INTO `tipologie_abbonamento` VALUES (1,'Small Jim','Sala Pesi, cardio',30),(2,'Medium Jim','Sala Pesi, cardio, corsi',40),(3,'Family','Sala Pesi, cardio, corsi',90),(5,'Big Jim','Accesso completo alla palestra, percorso arrampicata, personal trainer e supporto medico',200),(7,'Water Jim','Accesso ai corsi di nuoto, due lezioni settimanali.',80);
/*!40000 ALTER TABLE `tipologie_abbonamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `id_anagrafica` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(8) DEFAULT NULL,
  `id_tipologia_abbonamento` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  KEY `id_anagrafica` (`id_anagrafica`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`id_anagrafica`) REFERENCES `anagrafica` (`id_anagrafica`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,1,'SuperMarco89','1234',NULL),(2,2,'FerryBoat','1234',NULL),(3,4,'Alessandro','1234',NULL),(4,3,'StefaniaAv','1234',NULL),(5,5,'LorenzoMC','1234',NULL),(6,6,'primodeiprimi','1234',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-20 12:13:39
