-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: Big_Gym
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cat_attivita_sportive`
--

DROP TABLE IF EXISTS `cat_attivita_sportive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_attivita_sportive` (
  `id_cat` int(11) NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_cat`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_attivita_sportive`
--

LOCK TABLES `cat_attivita_sportive` WRITE;
/*!40000 ALTER TABLE `cat_attivita_sportive` DISABLE KEYS */;
INSERT INTO `cat_attivita_sportive` VALUES (1,'Abbonnamento'),(2,'Corso'),(3,'Attivita'),(4,'esempio');
/*!40000 ALTER TABLE `cat_attivita_sportive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corsi_in_programmazione`
--

DROP TABLE IF EXISTS `corsi_in_programmazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corsi_in_programmazione` (
  `id_corso_in_programmazione` int(11) NOT NULL AUTO_INCREMENT,
  `id_categoria` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_corso_in_programmazione`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corsi_in_programmazione`
--

LOCK TABLES `corsi_in_programmazione` WRITE;
/*!40000 ALTER TABLE `corsi_in_programmazione` DISABLE KEYS */;
/*!40000 ALTER TABLE `corsi_in_programmazione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `istruttori`
--

DROP TABLE IF EXISTS `istruttori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `istruttori` (
  `id_istruttore` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `cognome` varchar(50) DEFAULT NULL,
  `descrizione` varchar(500) DEFAULT NULL,
  `img` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_istruttore`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `istruttori`
--

LOCK TABLES `istruttori` WRITE;
/*!40000 ALTER TABLE `istruttori` DISABLE KEYS */;
INSERT INTO `istruttori` VALUES (1,'Aitano','Laiuano','Motto: Se il tuo sogno ha degli ostacoli è quello giusto. <br>\r\nSono un personal trainer con Diploma in Personal training e massaggiatore sportivo.','rock.png'),(2,'Fabio','Niseo','Motto: Nella vita, per avere successo, devi andare oltre gli obbiettivi imposti. <br>\r\nSono un nuotatore Agonista di livello nazionale oltre che istruttore e allenatore di nuoto. <br>\r\nGrazie all mia Laurea in Scienze delle attività Motorie e Sportive sono pronto a supportarti in ogni parte del tuo allenamento con professionalità e competenza.','michael.png'),(3,'Lorenzo','Barbarelli','Sei un atleta? O uno sportivo? La preparazione atletica permette di aumentare la forza muscolare, velocità, potenza, resistenza, lucidità mentale. <br>\r\nTi aiuto a raggiungere il risultato desiderato nel miglior modo possibile e mantenerlo nel tempo grazie ad un team specialistico.','Jim_Thorpe.png'),(4,'Barry','Djevajl','Motto: Lo sport insegna che la vittoria non basta il talento, ci vuole il lavoro e il sacrificio quotidiano. <br> Nello sport come nella vita. <br>\r\nPersonal trainer esperienza ventennale nel wellness e responsabile di sala.\r\n\r\n','Morrison.png'),(5,'Miriam','Toselli','Motto: I limiti esistono solo nell’anima di chi è a corto di sogni. <br>\r\nSono una Personal Trainer e istruttrice di sala pesi. <br>\r\nOffro preparazione atletica per sport di squadra e rieducazione post infortunio e post intervento.','Angelina.png'),(6,'Aristide','Torchia','Motto: Parti da dove sei, usa quello che hai e fai quello che puoi. <br>\r\nLaureato in scienze motorie nel 1990 con specializzazione in Fitness, Ginnastica posturale e Pilates.','Arnold.png'),(7,'Lucas','Corso','Motto: Per ogni individuo, lo sport è una possibile fonte di miglioramento interiore. <br>\r\nCollaboro con Big Jim dal 2003 e offro Power Pump e allenamento Body Building.','Sergente.png'),(8,'Nathan','Never','Motto: L’attività fisica è salute, rende la tua vita migliore, più bella! <br>\r\nSono laureato presso l’Isef nel 1990 con Master di specializzazione in ipertrofia, dimagrimento, allenamento al femminile, recupero funzionale. <br>\r\nMi specializzo in circuiti al femminile, circuiti per dimagrimento, allenamento a corpo libero, allenamento funzionale, allenament oper aumento massa magra (ipertrofia) e ginnastica per mal di schiena.','trainer2.png');
/*!40000 ALTER TABLE `istruttori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordini`
--

DROP TABLE IF EXISTS `ordini`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordini` (
  `id_ordine` int(11) NOT NULL AUTO_INCREMENT,
  `nome_cliente` varchar(255) DEFAULT NULL,
  `cognome_cliente` varchar(255) DEFAULT NULL,
  `totale_ordine` double DEFAULT NULL,
  `data_acquisto` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_ordine`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordini`
--

LOCK TABLES `ordini` WRITE;
/*!40000 ALTER TABLE `ordini` DISABLE KEYS */;
INSERT INTO `ordini` VALUES (3,'primo','dei primi',50,'2022-05-25','primo@gamil.it');
/*!40000 ALTER TABLE `ordini` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordini_prodotti`
--

DROP TABLE IF EXISTS `ordini_prodotti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordini_prodotti` (
  `id_ordine` int(11) DEFAULT NULL,
  `id_prodotto` int(11) DEFAULT NULL,
  KEY `id_ordine` (`id_ordine`),
  KEY `id_prodotto` (`id_prodotto`),
  CONSTRAINT `ordini_prodotti_ibfk_1` FOREIGN KEY (`id_ordine`) REFERENCES `ordini` (`id_ordine`),
  CONSTRAINT `ordini_prodotti_ibfk_2` FOREIGN KEY (`id_prodotto`) REFERENCES `prodotti` (`id_prodotto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordini_prodotti`
--

LOCK TABLES `ordini_prodotti` WRITE;
/*!40000 ALTER TABLE `ordini_prodotti` DISABLE KEYS */;
INSERT INTO `ordini_prodotti` VALUES (3,6);
/*!40000 ALTER TABLE `ordini_prodotti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prodotti`
--

DROP TABLE IF EXISTS `prodotti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prodotti` (
  `id_prodotto` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `descrizione` text DEFAULT NULL,
  `prezzo` double DEFAULT NULL,
  `img` varchar(50) DEFAULT NULL,
  `id_cat` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_prodotto`),
  KEY `id_cat_attivita_sportiva` (`id_cat`),
  CONSTRAINT `prodotti_ibfk_1` FOREIGN KEY (`id_cat`) REFERENCES `cat_attivita_sportive` (`id_cat`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prodotti`
--

LOCK TABLES `prodotti` WRITE;
/*!40000 ALTER TABLE `prodotti` DISABLE KEYS */;
INSERT INTO `prodotti` VALUES (1,'Small Jim','Sala Pesi, cardio.',30,NULL,1),(2,'Medium Jim','Sala Pesi, cardio, corsi.',40,NULL,1),(3,'Family','Sala Pesi, cardio, corsi.',90,NULL,1),(4,'Big Jim','Accesso completo alla palestra, percorso arrampicata, personal trainer e supporto medico.',200,NULL,1),(5,'Water Jim','Accesso all\'impianto della nostra piscina e ai corsi di nuoto,due lezioni settimanali.',80,NULL,1),(6,'Aerobica e Step Coreografico','La ginnastica aerobica è una sessione di workout in cui si susseguono vari esercizi eseguiti a corpo libero o con attrezzi come lo step, tutto nell’arco temporale di un’ora circa.',25,'step.png',2),(7,'Arrampicata Indoor','Il corso di arrampicata è rivolto a tutti coloro che desiderano affrontare un primo approccio nel mondo dell\'arrampicata sportiva in totale sicurezza.',30,'climbing.png',2),(8,'Calisthenics','Il calisthenics è l\'arte di usare il proprio peso corporeo come resistenza per allenarsi e sviluppare il fisico tramite un istema di allenamento basato sulla ginnastica a corpo libero.',30,'cali.jpg',2),(9,'Crosstraining','Il Cross Training, o allenamento incrociato, è una modalità di allenamento che permette di praticare più discipline sportive, variando ogni giorno le catene muscolari utilizzate e allenando costantemente il sistema cardio-respiratorio e la risposta ormonale all’esercizio fisico.',30,'fit.jpg',2),(10,'Dinamic Yoga','Ciò che viene chiamato Yoga dinamico si distingue da quello tradizionale poiché propone lo svolgimento di una concatenazione fluida di posture ad un ritmo rapido e sportivo, mantenendo una respirazione lenta e profonda.',25,'yoga.jpg',2),(11,'Fit Box\r\n','Fit boxe è un metodo di allenamento fitness, concepito per ottimizzare lo stato di forma fisica generale, sviluppato in stile kickboxing.',25,'box.jpg',2),(12,'Functional Training','\r\nGrazie alle diverse modalità di esecuzione e alle diverse velocità di contrazione muscolare, migliora la coordinazione tra i vari gruppi muscolari, sviluppa l\'agilità, aumenta l\'elasticità nelle articolazioni e il tono e la potenza muscolare.',25,'bilancere.png',2),(13,'Ginnastica Kids','L’esercizio fisico ha un ruolo prioritario per la salute durante lo sviluppo dei bambini. Oltre ad essere divertente, l’attività motoria nei più piccoli contribuisce a migliorare le condizioni di salute fisica e a promuovere il benessere psicologico, indispensabili per una crescita sana.',15,'child.png',2),(14,'Group Sparring','Un allenamento “one to one” a coppie che prende spunto dalla pre-pugilistica e dalle attività di sparring delle arti marziali, ma ricodificate in chiave fitness musicale.',25,'sparring.jpg',2),(15,'Musical Fitness','Fitness musicale di gruppo',25,'music.jpg',2),(16,'Pilates and Stretch','l corso di Stretch Pilates si propone di aiutare gli allievi a conoscere il proprio corpo al meglio, a tonificarlo, a decontrarlo e a migliorarlo.\r\nStretch Pilates è tonificazione muscolare applicata ad una respirazione ben precisa, alternata al dovuto stretching di rilassamento.',25,'aerobic.jpg',2),(17,'Rieducazione Posturale','La Rieducazione Posturale, meglio nota come Ginnastica Posturale, è una metodica specifica che consta di una serie di esercizi atti a riequilibrare le tensioni muscolo-legamentose del corpo.',40,'fisiotherapy.png',2),(18,'Water Endurance','Un mix di diverse discipline per migliorare la tua capacità aerobica in un total body workout intenso e a ritmo di musica.',30,'waterend.jpg',2),(19,'Water Hydrobike','L\'hydrobike assicura benefici anche a livello cardiovascolare in quanto migliora la resistenza caridiocircolatoria. Infatti, il massaggio idrico continuo stimola la circolazione, oltre che tonificare, grazie alla resistenza creata con l\'acqua senza peraltro aumentare eccessivamente la massa muscolare.',40,'hidrobyke.jpg',2),(20,'Water Tone','È un\'attività di media intensità, mirata a sviluppare la tonificazione di tutti i distretti muscolari attraverso esercizi di coordinazione a difficoltà crescente.',30,'swim.png',2);
/*!40000 ALTER TABLE `prodotti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `cognome` varchar(50) DEFAULT NULL,
  `anno_di_nascita` date DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `codice_fiscale` varchar(50) DEFAULT NULL,
  `citta` varchar(50) DEFAULT NULL,
  `provincia` varchar(2) DEFAULT NULL,
  `cap` varchar(5) DEFAULT NULL,
  `partita_iva` varchar(11) DEFAULT NULL,
  `indirizzo` varchar(150) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Primo','Dei Primi',NULL,'FirstBoy','1234','fhdjrueiwldpeori4',NULL,NULL,NULL,NULL,NULL,'primo@gamil.it');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utenti_cancellati`
--

DROP TABLE IF EXISTS `utenti_cancellati`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utenti_cancellati` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `utenti_cancellati_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utenti_cancellati`
--

LOCK TABLES `utenti_cancellati` WRITE;
/*!40000 ALTER TABLE `utenti_cancellati` DISABLE KEYS */;
/*!40000 ALTER TABLE `utenti_cancellati` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-25 19:15:36
