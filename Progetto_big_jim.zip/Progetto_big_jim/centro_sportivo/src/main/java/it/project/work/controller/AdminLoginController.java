package it.project.work.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import it.project.work.model.Admin;
import it.project.work.service.AdminService;

@Controller
@RequestMapping("/adminlogin")
public class AdminLoginController {
	
	@Autowired
	private AdminService service;
	
	
	@GetMapping
	public String getPage() {
		
		
		return "admin-login";
	}
	
	@PostMapping("/convalida")
	public String convalida(HttpServletRequest request, HttpSession session) {
		
		Admin a; 
		
		try {
			
			 a = service.getAdminByCredenziali(request.getParameter("username"), request.getParameter("password"));
	
		
		}catch (Exception e) {
			
			
			return "redirect:/adminlogin";
		}
		
		session.setAttribute("adminActive", a);
		
			return "redirect:/admin";

	}

}
