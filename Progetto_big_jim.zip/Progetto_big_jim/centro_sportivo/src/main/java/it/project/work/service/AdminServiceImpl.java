package it.project.work.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.project.work.dao.AdminDao;
import it.project.work.model.Admin;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	private AdminDao am;

	@Override
	public void adAdmin(Admin admin) {
		
		am.adAdmin(admin);

	}

	@Override
	public void updateAdmin(Admin admin) {
		
		am.updateAdmin(admin);

	}

	@Override
	public List<Admin> getAdmins() {
		
		return am.getAdmins();
	}

	@Override
	public void deleteAdmin(Admin admin) {
		
		am.deleteAdmin(admin);

	}

	@Override
	public Admin getAdminById(int id) {
		
		return am.getAdminById(id);
	}
	
	@Override
	public Admin getAdminByCredenziali(String username, String password) {
		
	    return  getAdmins().stream().filter(x-> x.getUsername()
	    		.equalsIgnoreCase(username)&&x.getPassword()
	    		.equals(password)).findAny().get();

	}

}
