package it.project.work.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import it.project.work.model.Admin;

@Repository
public class AdminDaoImpl implements AdminDao {
	
	@PersistenceContext
	private EntityManager em; 
	

	@Override
	@Transactional
	public void adAdmin(Admin admin) {
		
		em.persist(admin);
	}

	@Override
	@Transactional
	public void updateAdmin(Admin admin) {
		
		em.merge(admin);

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Admin> getAdmins() {
		
		return em.createQuery("SELECT a FROM Admin a").getResultList();
	}

	@Override
	@Transactional
	public void deleteAdmin(Admin admin) {
		
		em.remove(em.merge(admin));

	}

	@Override
	public Admin getAdminById(int id) {
		
		return em.find(Admin.class, id);
	}

}
