package it.project.work.controller;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.project.work.model.Istruttore;
import it.project.work.service.IstruttoreService;

@Controller
@RequestMapping("/administruttore")
public class AdminIstruttoreFormController {
	
  @Autowired IstruttoreService istService;
  @GetMapping
 public String getPage(
		 @RequestParam(name="modifica")String modifica,
		 @RequestParam(name ="id",required =false)String id,
		 Model model) {
	  
       model.addAttribute("modifica",modifica);
       
       if(id!=null)
         
    	   model.addAttribute(istService.getIstruttoreById(Integer.valueOf(id)));
       
      return "istruttori-form";

 }

  @PostMapping("/aggiungi")
  public String aggiungi(HttpServletRequest request) {
	  
      Istruttore i = new Istruttore();
      i.setNome(request.getParameter("nome"));
      i.setCognome(request.getParameter("cognome"));
      i.setDescrizione(request.getParameter("descrizione"));
      i.setNameImg(request.getParameter("nameImg"));
      istService.addIstruttore(i);
      
      return"redirect:/admin";
  }
  @PostMapping("/modifica")
  public String modifica(HttpServletRequest request) {
	  
      Istruttore i = istService.getIstruttoreById(Integer.valueOf(request.getParameter("id")));
      i.setCognome(request.getParameter("cognome"));
      i.setNome(request.getParameter("nome"));
      i.setDescrizione(request.getParameter("descrizione"));
      i.setNameImg(request.getParameter("nameImg"));
      istService.updateIstruttore(i);
      
      return "redirect:/admin";

  }



}