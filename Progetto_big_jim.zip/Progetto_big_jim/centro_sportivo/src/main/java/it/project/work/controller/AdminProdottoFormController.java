package it.project.work.controller;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.project.work.model.CatAttivitaSportive;
import it.project.work.model.Prodotto;
import it.project.work.service.CatAttivitaSportiveService;
import it.project.work.service.ProdottoService;

	// http://localhost:8080/centro_sportivo/adminprodottoform

@Controller
@RequestMapping("/adminprodottoform")
public class AdminProdottoFormController {
	
	@Autowired
	ProdottoService prodServ;
	
	@Autowired
	CatAttivitaSportiveService catServ;
	
	@GetMapping
	public String getPage(Model model) {
		
		List<CatAttivitaSportive> categorie = catServ.listAttivita();
		
		if (categorie.isEmpty()) {
			
			return "redirect:/admin?cat=null";
		}
			
		model.addAttribute("categorie", catServ.listAttivita());

		return "prodotto-form";
		
	}
	
	@PostMapping("/convalida")
	public String aggiungiProdotto(HttpServletRequest request) {
		
		Prodotto prod = new Prodotto();
		
		prod.setNome(request.getParameter("nome"));
		
		prod.setDescrizione(request.getParameter("descrizione"));
		
		prod.setInfo(request.getParameter("info"));
		
		double prezzo = Double.valueOf(request.getParameter("prezzo"));
		
		prod.setPrezzo(prezzo);
		
		prod.setImg(request.getParameter("img"));
		
		CatAttivitaSportive cat = catServ.getAttivitaById
				(
					Integer.valueOf(request.getParameter("id_cat"))
				); 
		
		prod.setCat(cat);
		
		prodServ.addProdotto(prod);
		
		return "redirect:/admin";
		
	}

	@PostMapping("/update")
    public String updateCorso(HttpServletRequest request, Model model) {
	
		Prodotto p = new Prodotto();
		
		p.setId_prodotto(Integer.valueOf(request.getParameter("id")));
		
		p.setNome(request.getParameter("nome"));
		
		p.setDescrizione(request.getParameter("descrizione"));
		
		double prezzo = Double.valueOf(request.getParameter("prezzo"));
		
		p.setPrezzo(prezzo);
		
		p.setCat(catServ.getAttivitaById(2));
		
		prodServ.updateProdotto(p);
   
        return "redirect:/admin";
    }
		
		@GetMapping("/corsocard")
		public String corsoCard(@RequestParam("id") String id,Model model) {
		
		Prodotto p = prodServ.getProdottoById(Integer.valueOf(id));
        
        if( p == null) {
            
            return "redirect:/admin";
        }
        
        model.addAttribute("prodotto", p);
        
        
        return "corso-card";

	}
	
}
