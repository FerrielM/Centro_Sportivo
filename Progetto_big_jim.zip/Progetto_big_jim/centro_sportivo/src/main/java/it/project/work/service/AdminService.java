package it.project.work.service;

import java.util.List;

import it.project.work.model.Admin;

public interface AdminService {
	public void adAdmin(Admin admin);
	
	public void updateAdmin(Admin admin);
	
	public List<Admin> getAdmins();
	
	public void deleteAdmin(Admin admin);
	
	public Admin getAdminById(int id);

	Admin getAdminByCredenziali(String username, String password);

}
