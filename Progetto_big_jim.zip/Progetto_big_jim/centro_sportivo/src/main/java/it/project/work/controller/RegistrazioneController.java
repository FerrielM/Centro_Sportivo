package it.project.work.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import it.project.work.model.User;
import it.project.work.service.UserService;

@Controller
@RequestMapping("/registrazione")
public class RegistrazioneController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	@GetMapping
	public String getPage() {
		return "registrazione";
	}  
	@ResponseBody
	@PostMapping("/convalida")
		public String convalida(HttpServletRequest request) {
		
		String response="save success";
		User user =new User();
		System.out.println( request.getParameter("nome")==null);
		
 		try {
			
		user.setNome(request.getParameter("nome"));
		user.setAnnoDiNascita(userService.checkData(request.getParameter("anno")));
		user.setCognome(request.getParameter("cognome"));
		user.setUsername(request.getParameter("username"));
		user.setPassword(encoder.encode(request.getParameter("password")));
		user.setCitta(request.getParameter("citta"));
		user.setCap(request.getParameter("cap"));
		user.setCodiceFiscale(request.getParameter("codicefiscale"));
		user.setEmail(request.getParameter("email"));
		user.setProvincia(request.getParameter("provincia"));
		user.setIndirizzo(request.getParameter("indirizzo"));
	if(	userService.verificaUser(user))
		response="operation error";
	else 
		userService.addUser(user);
		
		}catch(Exception e) {
			
			response="operation error";
		}
		
		return response;
	}	
}