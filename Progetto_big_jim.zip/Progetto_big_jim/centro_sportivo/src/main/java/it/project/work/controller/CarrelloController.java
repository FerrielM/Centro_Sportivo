
package it.project.work.controller;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.project.work.model.Prodotto;
import it.project.work.service.ProdottoService;

@Controller
@RequestMapping("/cart")

class CarrelloController {
	@Autowired
private ProdottoService prodService;
	 
	@GetMapping 
	@SuppressWarnings("unchecked")
	 public String getPage(Model model, HttpSession  session,
			 @RequestParam(name="path", required= false)String path,
			 @RequestParam(name="id", required=false)String id,
			 @RequestParam(name="quantita", required=false) String quantita) { 
		
		System.out.println(id);
		
		int quant = 0;
		
		List<Prodotto> articles = new ArrayList<>();
		
		if (session.getAttribute("quantita") == null) {
			session.setAttribute("quantita", quant);
			
		} 
		
		if (quantita != null) {
			quant = Integer.valueOf(quantita);
			session.setAttribute("quantita", quant);
		}
		
		if(id!=null) {
			Prodotto  p = prodService.getProdottoById(Integer.valueOf(id));
			
			if(session.getAttribute("articles")!=null) 

				articles =(List<Prodotto>) session.getAttribute("articles");
			
				if (checkCarrello(articles, Integer.valueOf(id))){
					
					articles.add(p);
					
					session.setAttribute("articles", articles);
				}
			
     	}else {
     		if(session.getAttribute("articles")==null)
     			session.setAttribute("articles", articles);
     		else {
     			articles=(List<Prodotto>)session.getAttribute("articles");
     			session.setAttribute("articles", articles);
     		}
     		return "cart";
     	}
		if(path==null)
		return "redirect:/corsi";
		
		else
			model.addAttribute("id",id);
			return "redirect:/"+path;
	}
	
	
	private boolean checkCarrello(List<Prodotto> p, int id) {
		
		for(Prodotto prod : p) {
			
			if(prod.getId_prodotto() == id) 
				
				
				return false;

		}
		return true;
		
		
	}
}
