package it.project.work.controller;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import it.project.work.model.Istruttore;
import it.project.work.model.Ordine;
import it.project.work.model.Prodotto;
import it.project.work.model.User;
import it.project.work.service.IstruttoreService;
import it.project.work.service.OrdineService;
import it.project.work.service.ProdottoService;
import it.project.work.service.UserService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private OrdineService ordineService;
	
	@Autowired
	private ProdottoService prodottoService;
	
	@Autowired
	private IstruttoreService istService;

	@GetMapping
	public String getPage(Model model ,HttpSession session ) {
		
        if(session.getAttribute("adminActive")==null){
        	
            return "redirect:/adminlogin";
        }
		
        List<User>users = new ArrayList<>();
        
        if(userService.getUsers().isEmpty())
        	
            model.addAttribute("users",users);
        else
        	
     model.addAttribute("users",userService.getUsers());

        List<Prodotto>prodotti=new ArrayList<>();
        
        if(prodottoService.getProdotti().isEmpty())
        	
            model.addAttribute("prodotti",prodotti);
        else
        	
     model.addAttribute("prodotti",prodottoService.getProdotti());

    List<Ordine> ordini =new ArrayList<>();
    
       if(ordineService.getOrdini().isEmpty())
    	   
           model.addAttribute("ordini",ordini);
       
       else 
    	   
           model.addAttribute("ordini",ordineService.getOrdini());
       
      List<Istruttore> istruttori=new ArrayList<>();
      
      if(istService.getIstruttori().isEmpty())
    	  
              model.addAttribute("istruttore",istruttori);
      
      else model.addAttribute("istruttore",istService.getIstruttori());

    return "area-admin";

    }
	 
	@GetMapping("/adminhome")
    public String adminhome() {
	
        return"/admin-login";

    }
	
	
	@GetMapping("/deleteuser")
	public String deleteUser(@RequestParam("id") String id) {
	
		if (id != null) {
		
		userService.deleteUser(userService.getUser(Integer.valueOf(id)));
		
		}
		
		return "redirect:/admin";
		
	}

    @GetMapping("/deleteprodotto")
	public String deleteProdotto(Model model,@RequestParam("id")String id) {
     
        Prodotto prodotto = prodottoService.getProdottoById(Integer.valueOf(id)); 
        
        prodotto.setCat(null);
        
        		prodottoService.updateProdotto(prodotto);

            	prodottoService.deleteProdotto(prodotto);

        	return "redirect:/admin";

    }
	
	
	
	@GetMapping("/deleteordine")
	public String deleteOrdine(@RequestParam("id") String id,Model model) {
	
		Ordine ordine = ordineService.getOrdineById(Integer.valueOf(id));
		
		if (!ordine.getProdotti().isEmpty()) {
			
			List<Prodotto> corsi = ordine.getProdotti();
			
			corsi.clear();
			
			ordineService.updateOrdine(ordine);
	
		}
			
			ordineService.deleteOrdine(ordine);
			
			return "redirect:/admin";
	
		}
	
	@GetMapping("deleteistruttore")
	public String deleteIstruttore(@RequestParam("id") String id, Model model) {
		
		Istruttore ist = istService.getIstruttoreById(Integer.valueOf(id));
		
		istService.deleteIstruttore(ist);
		
		return "redirect:/admin";
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		
		session.setAttribute("adminActive", false);
		
		return "redirect:/adminlogin";
	}

}
