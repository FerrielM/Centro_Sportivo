package it.project.work.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.project.work.model.CatAttivitaSportive;
import it.project.work.service.CatAttivitaSportiveService;

// http://localhost:8080/centro_sportivo/admincatform
@Controller
@RequestMapping("/admincatform")
public class AdminCatFormController {
	
	
	@Autowired
	CatAttivitaSportiveService catService;
	
	
	@GetMapping
	private String getPage() {
		
		
		return "categoria-form";
	}

	
	@PostMapping("/convalida")
	private String convalida(@RequestParam("descrizione") String descrizione) {
		
		CatAttivitaSportive cat = new CatAttivitaSportive();
		
		cat.setDescrizione(descrizione);
		
		catService.createAttivita(cat);
		
		return "redirect:/admin";
		
	}
}
