package it.project.work.dao;

import java.util.List;

import it.project.work.model.Admin;

public interface AdminDao {
	
	public void adAdmin(Admin admin);
	
	public void updateAdmin(Admin admin);
	
	public List<Admin> getAdmins();
	
	public void deleteAdmin(Admin admin);
	
	public Admin getAdminById(int id);

}
