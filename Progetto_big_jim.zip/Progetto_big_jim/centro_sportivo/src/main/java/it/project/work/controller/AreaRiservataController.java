package it.project.work.controller;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import it.project.work.model.Ordine;
import it.project.work.model.User;
import it.project.work.service.OrdineService;

@Controller
@RequestMapping("/areariservata")
public class AreaRiservataController {
	
	@Autowired
	private OrdineService orderSerivce;

	@GetMapping
    public String getPage(HttpSession session,Model model) {
		
       List<Ordine> ordiniUtente =new ArrayList<>();
       
	if (session.getAttribute("isLoggato") == null ||(Boolean)session.getAttribute("isLoggato") == false ) {
		
		session.setAttribute("isLoggato", false);
		
		return "redirect:/index";
	}	

        boolean ordiniPresenti=false;
        
        try {
        	
         User u =(User)session.getAttribute("user");
         
         ordiniUtente = orderSerivce.getOrdiniPerUser(u.getUsername());
         
         
       session.setAttribute("ordini",ordiniUtente);
       
       if(!ordiniUtente.isEmpty())
    	   
      ordiniPresenti=true;

        }catch(Exception e) {
        	
            e.printStackTrace();
            
            ordiniPresenti = false;
            
            model.addAttribute("ordiniPresenti",false);
            
            return "area-riservata";
        }
         model.addAttribute("ordiniPresenti",ordiniPresenti);
         
        return "area-riservata";

   }
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		
		session.setAttribute("isLoggato", null);

		return "redirect:/index";
	}
	
}
	

