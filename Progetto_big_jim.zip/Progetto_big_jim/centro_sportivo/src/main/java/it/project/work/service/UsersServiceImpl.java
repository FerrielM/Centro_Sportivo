package it.project.work.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import it.project.work.dao.UserDao;
import it.project.work.model.User;
@Service
public class UsersServiceImpl implements UserService{
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private BCryptPasswordEncoder decoder;
	
	@Override
	public User getUser(int id) {
		return userDao.getUser(id);
	}

	@Override
	public List<User> getUsers() {
		return userDao.getUsers();
	}

	@Override
	public void addUser(User user) {
		userDao.addUser(user);
	}

	@Override
	public void deleteUser(User user) {
     userDao.deleteUser(user);		
	}

	@Override
	public void updateUser(User user) {
		userDao.updateUser(user);
		
	}

	@Override
	public boolean convalida(String email,String password) {
		
		boolean esito = getUsers().stream().anyMatch(x->x.getEmail().equalsIgnoreCase(email) && decoder.matches(password, x.getPassword()));
		
 		return esito;
	}

	@Override
	public User getUserByCredenziali(String email, String password) {
		
		Predicate<User>condizione =x-> x.getEmail().equalsIgnoreCase(email) && decoder.matches(password, x.getPassword());
		
			return getUsers().stream().filter(condizione).findAny().get();
     
	}

	@Override
	public Date checkData(String data) {
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			
	return	format.parse(data);
		}catch(Exception e) {
			return null;
		}	
  	}

	@Override
	public boolean verificaUser(User user) {
		return getUsers().stream().anyMatch(x->x.getUsername().equalsIgnoreCase(user.getUsername())||
				 x.getEmail().equalsIgnoreCase(user.getEmail())|| x.getCodiceFiscale().equalsIgnoreCase(user.getCodiceFiscale())
				 	 );
		 
	}
	
	
	 
 
 

}
