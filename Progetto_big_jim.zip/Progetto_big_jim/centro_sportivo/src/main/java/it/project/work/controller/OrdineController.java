package it.project.work.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import it.project.work.model.Ordine;
import it.project.work.model.Prodotto;
import it.project.work.model.User;
import it.project.work.service.OrdineService;
import it.project.work.service.UserService;

@Controller
@RequestMapping("/ordini")
public class OrdineController {
	
	@Autowired
	private OrdineService ordineService;
	@Autowired
	private UserService userService;
	
	@SuppressWarnings("unchecked")
	@PostMapping("/esegui")
	@ResponseBody
	public String creaOrdine(HttpSession session, Model model, HttpServletRequest request) {

		User u = new User();
		Ordine o = new Ordine();
		
		try {
	
			o.setNome_cliente(request.getParameter("nome"));
			o.setCognome_cliente(request.getParameter("cognome"));
			o.setEmail(request.getParameter("email"));
			o.setData_acquisto(new Date());
			o.setTotaleOrdine(Double.valueOf(request.getParameter("tot")));
			
			o.setProdotti((List<Prodotto>) session.getAttribute("articles"));
			
		if ((u = userService.getUser(Integer.valueOf(request.getParameter("user")))) == null ) {
				
			ordineService.createOrdini(o);
			
			
			return "save success";

		} else {
			
			final User u2 = userService.getUser(Integer.valueOf(request.getParameter("user")));
			
			o.setUsername(u.getUsername());
			
			ordineService.createOrdini(o);
			
			session.setAttribute("articles", new ArrayList<Prodotto>());
			
			model.addAttribute("prodotti", ordineService.getOrdini()
					.stream().filter(x -> x.getUsername()
							.equals(u2.getUsername())).collect(Collectors.toList()));
			
			return "save success";
		}
		
	} catch (Exception e) {
		
		e.printStackTrace();
		
		return "";
		
	}
		
	
	}
	
}
