	$(document).ready(function(){

		document.getElementById("carrello").addEventListener("click", function(){
			
				let quan = document.getElementById("quantita").value.replace(" ", "");
				let id = document.getElementById("id_corso").value
				let l = '/centro_sportivo/cart?id=' + id + '&path=corsi/viewcorso&quantita=' + quan;
				
				document.getElementById("carrello").setAttribute("href", l)
		})
	});