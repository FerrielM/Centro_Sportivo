$(document).ready(function()
{ 
	//funzione di controllo validità campi
	function checkData()
	{

		let expressionEmail = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		let expressionPassword = /^[A-Za-z0-9@$!%*#?&]{7,50}$/;
		
		return new Array
		(
			expressionEmail.test($('#emailReg').val()),
			expressionPassword.test($('#passwordReg').val())			
		);
	}
	
	//funzione di invio dati in post al controller
	function sendData()
	{
		$.post
	    (
	      'login/convalida',
	      {
		
	        email:$('#email').val(),
	        password:$('#password').val()
	      },
	      function (response)
	      {
	       
	        if (response === 'save success'){
		
			location.href = '/centro_sportivo/index';
			
		}else{
				
				$("#loginError").css({"display":"block"});

			}
			
	      }
	    );
	}
	
	//azione click button di registrazione
	$('#submit').click(function()
	{
		let verifiedData = checkData();
		if (verifiedData[0] && 
			verifiedData[1])
			{
				sendData();
			}

	});
	
	//reset dei messaggi di errore al focus
	
	$('#email').focusin(function ()
	{
	  $('#loginError').css({'display':'none'});
	});
	
	$('#password').focusin(function ()
	{
	  $('#loginError').css({'display':'none'});
	});
	
});