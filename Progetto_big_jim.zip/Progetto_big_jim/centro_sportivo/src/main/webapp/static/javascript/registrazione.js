$(document).ready(function()
{
	//funzione di controllo validità campi
	function checkData()
	{
		
		let pass = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
		
		let today = new Date();
		let birthday = new Date($('#annoReg').val());

		let expressionNome = /^[a-zA-Zàéèìòù\s']{2,50}$/i;
		let expressionUsername = /^[a-z0-9àéèìòù\s'\.,-]{1,255}$/i;
		let expressionEmail = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		let expressionIndirizzo =/^[a-z0-9àéèìòù\s'\.,-]{1,255}$/i;
		let expressionCap = /^[0-9]{5}$/;
		let expressionPassword = /^[a-zA-Z0-9àéèìòù\s']{2,50}$/i;
		let expressionCodiceFiscale = /^(?:[A-Z][AEIOU][AEIOUX]|[AEIOU]X{2}|[B-DF-HJ-NP-TV-Z]{2}[A-Z]){2}(?:[\dLMNP-V]{2}(?:[A-EHLMPR-T](?:[04LQ][1-9MNP-V]|[15MR][\dLMNP-V]|[26NS][0-8LMNP-U])|[DHPS][37PT][0L]|[ACELMRT][37PT][01LM]|[AC-EHLMPR-T][26NS][9V])|(?:[02468LNQSU][048LQU]|[13579MPRTV][26NS])B[26NS][9V])(?:[A-MZ][1-9MNP-V][\dLMNP-V]{2}|[A-M][0L](?:[1-9MNP-V][\dLMNP-V]|[0L][1-9MNP-V]))[A-Z]$/i;
		let expressionCitta = /^([a-zA-Z\u0080-\u024F]+(?:. |-| |'))*[a-zA-Z\u0080-\u024F]*$/;
		let expressionProvincia = /^[a-zA-Z]{2}$/;
		
		return new Array
		(
			expressionNome.test($('#nomeReg').val()),
			expressionNome.test($('#cognomeReg').val()),
			expressionUsername.test($('#usernameReg').val()),
			expressionEmail.test($('#emailReg').val()),
			expressionCodiceFiscale.test($('#codicefiscaleReg').val()),
			birthday < today,
			expressionIndirizzo.test($('#indirizzoReg').val()),
			expressionCitta.test($('#cittaReg').val()),
			expressionCap.test($('#capReg').val()),
			expressionProvincia.test($('#provinciaReg').val()),
			expressionPassword.test($('#passwordReg').val()),
			$('#passwordValidReg').val() === $('#passwordReg').val(),
			$('#accept').is(':checked')
			
		);
	}
	
	//funzione di invio dati in post al controller
	function sendData()
	{
		$.post
	    (
	      'registrazione/convalida',
	      {
			nome:$('#nomeReg').val(),
	        cognome:$('#cognomeReg').val(),
	        username:$('#usernameReg').val(),
	        email:$('#emailReg').val(),
	        codicefiscale:$('#codicefiscaleReg').val(),
	        anno:$('#annoReg').val(),
	        indirizzo:$('#indirizzoReg').val(),
	        citta:$('#cittaReg').val(),
	        cap:$('#capReg').val(),
	        provincia:$('#provinciaReg').val(),
	        password:$('#passwordReg').val()
	      },
	      function (response)
	      {
	        if (response === 'save success')
				location.href = '/centro_sportivo/index';
			else
				$('#errorAlert').css({'display':'block'});
	      }
	    );
	}
	
	//azione click button di registrazione
	$('#submitReg').click(function()
	{
		let verifiedData = checkData();
		if (verifiedData[0] && 
			verifiedData[1] && 
			verifiedData[2] && 
			verifiedData[3] && 
			verifiedData[4] &&
			verifiedData[5] &&
			verifiedData[6] && 
			verifiedData[7] && 
			verifiedData[8] && 
			verifiedData[9] && 
			verifiedData[10] && 
			verifiedData[11])
			{
				sendData();
			}
		else
		{
			if (!verifiedData[0])
			{
				$('#nameError').css({'display':'block'});
				$('#nomeReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[1])
			{
				$('#surnameError').css({'display':'block'});
				$('#cognomeReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[2])
			{
				$('#usernameError').css({'display':'block'});
				$('#usernameReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[3])
			{
				$('#emailError').css({'display':'block'});
				$('#emailReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[4])
			{
				$('#codiceFiscaleError').css({'display':'block'});
				$('#codicefiscaleReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[5])
			{
				$('#dataError').css({'display':'block'});
				$('#annoReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[6])
				{
					$('#indirizzoError').css({'display':'block'});
					$('#indirizzoReg').css({'border':'1px solid red'});
					return;
				}
				
			if (!verifiedData[7])
			{
				$('#cittaError').css({'display':'block'});
				$('#cittaReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[8])
			{
				$('#capError').css({'display':'block'});
				$('#capReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[9])
			{
				$('#provError').css({'display':'block'});
				$('#provinciaReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[10])
			{
				$('#passwordError').css({'display':'block'});
				$('#passwordReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[11])
			{
				$('#passwordError2').css({'display':'block'});
				$('#passwordValidReg').css({'border':'1px solid red'});
				return;
			}
			
			if (!verifiedData[12])
			{
				$('#acceptError').css({'display':'block'});
				$('#accept').css({'border':'1px solid red'});
				return;
			}
		}
	});
	
	//reset dei messaggi di errore al focus
	$('#nomeReg').focusin(function ()
	{
	  $('#nameError').css({'display':'none'});
	  $('#nomeReg').css({'border':''});
	});
	
	$('#cognomeReg').focusin(function ()
	{
	  $('#surnameError').css({'display':'none'});
	  $('#cognomeReg').css({'border':''});
	});
	
	$('#usernameReg').focusin(function ()
	{
	  $('#usernameError').css({'display':'none'});
	  $('#usernameReg').css({'border':''});
	});
	
	$('#emailReg').focusin(function ()
	{
	  $('#emailError').css({'display':'none'});
	  $('#emailReg').css({'border':''});
	});
	
	$('#codicefiscaleReg').focusin(function ()
	{
	  $('#codiceFiscaleError').css({'display':'none'});
	  $('#codicefiscaleReg').css({'border':''});
	});
	
	$('#annoReg').focusin(function ()
	{
	  $('#dataError').css({'display':'none'});
	  $('#annoReg').css({'border':''});
	});		
	
	$('#indirizzoReg').focusin(function ()
	{
	  $('#indirizzoError').css({'display':'none'});
	  $('#indirizzoReg').css({'border':''});
	});
	
	$('#cittaReg').focusin(function ()
	{
	  $('#cittaError').css({'display':'none'});
	  $('#cittaReg').css({'border':''});
	});
	
	$('#capReg').focusin(function ()
	{
	  $('#capError').css({'display':'none'});
	  $('#capReg').css({'border':''});
	});
	
	$('#provinciaReg').focusin(function ()
	{
	  $('#provError').css({'display':'none'});
	  $('#provinciaReg').css({'border':''});
	});
	
	$('#passwordReg').focusin(function ()
	{
	  $('#passwordError').css({'display':'none'});
	  $('#passwordReg').css({'border':''});
	});
	
	$('#passwordValidReg').focusin(function ()
	{
	  $('#passwordError2').css({'display':'none'});
	  $('#passwordValidReg').css({'border':''});
	});		
	
	$('#accept').focusin(function ()
	{
	  $('#acceptError').css({'display':'none'});
	  $('#accept').css({'border':''});
	});		
});