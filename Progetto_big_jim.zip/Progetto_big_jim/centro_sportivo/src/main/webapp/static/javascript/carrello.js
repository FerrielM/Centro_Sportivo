	$(document).ready(function(){
		
		//Calcola totale tabella
			let quantita =  document.getElementsByClassName("quantity");
			let prezzi = document.getElementsByClassName("prezzo");
			let record = document.getElementsByClassName("record");
			let totale = 0;
			let parziale = 0;
			let refresh = document.getElementById("rf");
			
			refresh.addEventListener("click", function(){
				
				totale = 0;
				parziale = 0;
				
				for (let i = 0; i < prezzi.length; i++){
				
				let q = parseFloat(quantita[i].value);
				let p = parseFloat(prezzi[i].innerHTML.replace("€", "").replace(" ", ""));
				
				parziale = parseFloat(q * p);
				
				if(q > 1){
					
					parziale = parseFloat(parziale * 85 / 100);
				}
				
			    totale += parseFloat(parziale);
			    
			    
			}
			console.log(totale)
			document.getElementById("total").innerHTML = "€ " + ((Math.round(totale * 100) / 100).toFixed(2)).replace(".", ",");
				
			})
			
			for (let i = 0; i < prezzi.length; i++){
				
				let q = parseFloat(quantita[i].value);
				let p = parseFloat(prezzi[i].innerHTML.replace("€", "").replace(" ", ""));
				
				parziale = parseFloat(q * p);
				
				if(q > 1){
					
					parziale = parseFloat(parziale * 85 / 100);
				}
				
			    totale += parseFloat(parziale);
			    
			   
			    
			}
			console.log(totale)
			document.getElementById("total").innerHTML = "€ " + ((Math.round(totale * 100) / 100).toFixed(2)).replace(".", ",");
			
	  		//Mostra card carrello vuoto
			if(totale <= 0){
				
				$("#cart-empty").css({'display':'block'});
				$("#cart-full").css({'display':'none'});
				$("#checkout").css({'display':'none'});
			}
			
			//Mostra card carrello pieno
			if(totale > 0){
				
				$("#cart-empty").css({'display':'none'});
				$("#cart-full").css({'display':'block'});
				$("#checkout").css({'display':'block'});
			}
			
			
		//funzione di controllo validità campi form di pagamento
		function checkData()
		{

			let expressionNome = /^[a-zA-Zàéèìòù\s']{2,50}$/i;
			let expressionEmail = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			
			return new Array
			(
				expressionNome.test($('#nomePag').val()),
				expressionNome.test($('#cognomePag').val()),
				expressionEmail.test($('#emailPag').val())			
			);
		}
		
		//funzione di invio dati in post al controller
		function sendData()
		{

			$.post
		    (
		      "ordini/esegui",
		      {
				user:$("#usernamePag").val(),
				nome:$('#nomePag').val(),
		        cognome:$('#cognomePag').val(),
		        email:$('#emailPag').val(),
		        tot: totale
		      },
		      function (response)
		      {
		        if (response === 'save success'){
		        	$("#paymentSucc").css({'display':'block'});
		        // inserire div da far comparire con .css.style
					location.href = '/centro_sportivo/index';
				}else
					$('#errorAlert').css({'display':'block'});
		      }
		    );
		}
		
		//azione click button di registrazione
		$('#submitPag').click(function()
		{
			let verifiedData = checkData();
			if (verifiedData[0] && 
				verifiedData[1] && 
				verifiedData[2])
				{
					sendData();
				}
			else
			{
				if (!verifiedData[0])
				{
					$('#paymentNameError').css({'display':'block'});
					$('#nomePag').css({'border':'1px solid red'});
					return;
				}
				
				if (!verifiedData[1])
				{
					$('#paymentSurnameError').css({'display':'block'});
					$('#cognomePag').css({'border':'1px solid red'});
					return;
				}
				
				if (!verifiedData[2])
				{
					$('#paymentEmailError').css({'display':'block'});
					$('#emailPag').css({'border':'1px solid red'});
					return;
				}
			
			}
		});
		
		//reset dei messaggi di errore al focus
		$('#nomePag').focusin(function ()
		{
		  $('#paymentNameError').css({'display':'none'});
		  $('#nomePag').css({'border':''});
		});
		
		$('#cognomePag').focusin(function ()
		{
		  $('#paymentSurnameError').css({'display':'none'});
		  $('#cognomePag').css({'border':''});
		});
		
		$('#emailPag').focusin(function ()
		{
		  $('#paymentEmailError').css({'display':'none'});
		  $('#emailPag').css({'border':''});
		});
	});